"use client"

import { useEffect, useState } from "react"
import { useParams, useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Check } from "lucide-react"
import { useAuth } from "@/lib/auth-context"
import { mockShowtimes, mockMovies } from "@/lib/mock-data"

interface Seat {
  _id?: string
  id?: string
  row: string
  number: number
  status?: "available" | "booked" | "reserved"
  isAvailable?: boolean
}

interface ShowTime {
  _id?: string
  id?: string
  movieId: string
  date?: string
  time: string
  hall?: string
  basePrice?: number
  price?: number
}

interface Movie {
  _id?: string
  id?: string
  title: string
}

export default function SeatSelection() {
  const params = useParams()
  const router = useRouter()
  const { user, isLoading: authLoading } = useAuth()
  const showtimeId = (params.id as string) || ""

  const [seats, setSeats] = useState<Seat[]>([])
  const [showTime, setShowTime] = useState<ShowTime | null>(null)
  const [movie, setMovie] = useState<Movie | null>(null)
  const [selectedSeats, setSelectedSeats] = useState<string[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/auth/login")
    }
  }, [user, authLoading, router])

  useEffect(() => {
    const fetchData = async () => {
      try {
        console.log("[v0] Fetching seats for showTimeId:", showtimeId)

        let seatsData: Seat[] = []
        let showtimeData: ShowTime | null = null

        try {
          const seatsRes = await fetch(`/api/seats/${showtimeId}`)
          const response = await seatsRes.json()
          if (response.data && response.data.length > 0) {
            seatsData = response.data.map((s: any) => ({
              _id: s._id || s.id,
              id: s.id || s._id,
              row: s.row,
              number: s.number,
              status: s.status || (s.isAvailable ? "available" : "booked"),
            }))
          }
        } catch (error) {
          console.log("[v0] Seats API failed, generating mock seats")
        }

        // Generate mock seats if API failed
        if (seatsData.length === 0) {
          const rows = ["A", "B", "C", "D", "E", "F", "G", "H"]
          const seatsPerRow = 12
          seatsData = []
          for (const row of rows) {
            for (let i = 1; i <= seatsPerRow; i++) {
              seatsData.push({
                id: `${showtimeId}-${row}${i}`,
                row,
                number: i,
                status: Math.random() > 0.3 ? "available" : "booked",
              })
            }
          }
        }

        setSeats(seatsData)

        try {
          const showRes = await fetch(`/api/showtimes/${showtimeId}`)
          const response = await showRes.json()
          if (response.data) {
            showtimeData = response.data
          }
        } catch (error) {
          console.log("[v0] Showtime API failed")
        }

        // Fall back to mock showtime
        if (!showtimeData) {
          const mockShow = mockShowtimes.find((st) => st.id === showtimeId)
          if (mockShow) {
            showtimeData = {
              id: mockShow.id,
              movieId: mockShow.movieId,
              time: mockShow.time,
              price: mockShow.price,
              basePrice: mockShow.price,
              format: mockShow.format,
              hall: "1",
            }
          }
        }

        setShowTime(showtimeData)

        if (showtimeData) {
          let movieData: Movie | null = null
          try {
            const movieRes = await fetch(`/api/movies/${showtimeData.movieId}`)
            const response = await movieRes.json()
            if (response.data) {
              movieData = response.data
            }
          } catch (error) {
            console.log("[v0] Movie API failed")
          }

          if (!movieData) {
            const mockMovie = mockMovies.find((m) => m.id === showtimeData.movieId)
            if (mockMovie) {
              movieData = { id: mockMovie.id, title: mockMovie.title }
            }
          }

          setMovie(movieData)
        }
      } catch (error) {
        console.error("[v0] Failed to fetch data:", error)
      } finally {
        setLoading(false)
      }
    }

    if (user && showtimeId) {
      fetchData()
    }
  }, [showtimeId, user])

  if (!user && !authLoading) {
    return null
  }

  const toggleSeat = (seatId: string, status: string) => {
    if (status !== "available") return

    setSelectedSeats((prev) => (prev.includes(seatId) ? prev.filter((id) => id !== seatId) : [...prev, seatId]))
  }

  const handleBooking = async () => {
    if (selectedSeats.length === 0) {
      alert("Please select at least one seat")
      return
    }

    const totalPrice = (showTime?.basePrice || showTime?.price || 250) * selectedSeats.length

    router.push(`/confirmation/${showTime?._id || showTime?.id}?seats=${selectedSeats.join(",")}&price=${totalPrice}`)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    )
  }

  const rows = Array.from(new Set(seats.map((s) => s.row))).sort()

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-card border-b border-border sticky top-0 z-40 backdrop-blur-md bg-opacity-80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <Link href={`/movie/${showTime?.movieId}`}>
            <Button variant="ghost" size="sm" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Movie
            </Button>
          </Link>
          {movie && (
            <div>
              <h1 className="text-2xl font-bold text-foreground">{movie.title}</h1>
              <p className="text-muted-foreground">{showTime && `${showTime.time} • Hall ${showTime.hall || "1"}`}</p>
            </div>
          )}
        </div>
      </div>

      {/* Seat Selection */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="animate-slide-up">
          {/* Screen */}
          <div className="mb-12">
            <div className="flex items-center justify-center mb-8">
              <div className="bg-gradient-to-b from-primary/50 to-accent/20 rounded-full w-4/5 h-2 relative">
                <p className="text-center text-muted-foreground text-sm absolute -top-8 left-1/2 transform -translate-x-1/2 font-semibold">
                  SCREEN
                </p>
              </div>
            </div>

            {/* Seats Grid */}
            <div className="bg-gradient-to-b from-card/80 to-card border border-border rounded-xl p-8 shadow-lg">
              {rows.map((row, rowIndex) => (
                <div
                  key={row}
                  className="flex items-center gap-3 mb-4 animate-slide-in"
                  style={{ animationDelay: `${rowIndex * 30}ms` }}
                >
                  <span className="w-8 text-center font-bold text-primary min-w-8 text-lg">{row}</span>
                  <div className="flex gap-2 flex-wrap justify-center flex-1">
                    {seats
                      .filter((s) => s.row === row)
                      .sort((a, b) => a.number - b.number)
                      .map((seat) => {
                        const seatId = seat._id || seat.id
                        const seatStatus = seat.status || (seat.isAvailable ? "available" : "booked")
                        const isSelected = selectedSeats.includes(seatId)

                        return (
                          <button
                            key={seatId}
                            onClick={() => toggleSeat(seatId, seatStatus)}
                            disabled={seatStatus !== "available"}
                            title={`Seat ${row}${seat.number}`}
                            className={`
                              w-10 h-10 rounded-lg font-bold text-xs transition-all duration-300 flex items-center justify-center
                              ${
                                isSelected
                                  ? "bg-gradient-to-br from-primary to-accent text-white scale-110 shadow-lg shadow-primary/50 border border-primary"
                                  : seatStatus === "available"
                                    ? "bg-secondary text-secondary-foreground hover:border-primary border-2 border-border hover:scale-105 cursor-pointer"
                                    : "bg-muted/30 text-muted-foreground cursor-not-allowed opacity-40 border border-muted"
                              }
                            `}
                          >
                            {isSelected ? <Check className="w-4 h-4" /> : <span>{seat.number}</span>}
                          </button>
                        )
                      })}
                  </div>
                  <span className="w-8 text-center font-bold text-primary min-w-8 text-lg">{row}</span>
                </div>
              ))}
            </div>

            {/* Legend */}
            <div className="flex gap-6 mt-8 justify-center flex-wrap px-4">
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-secondary rounded-md border-2 border-border" />
                <span className="text-sm text-muted-foreground font-medium">Available</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-gradient-to-br from-primary to-accent rounded-md" />
                <span className="text-sm text-muted-foreground font-medium">Selected</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-6 h-6 bg-muted/30 rounded-md" />
                <span className="text-sm text-muted-foreground font-medium">Booked</span>
              </div>
            </div>
          </div>

          {/* Summary and Button */}
          <div className="bg-gradient-to-r from-card to-card/80 border border-border rounded-xl p-6 sticky bottom-0 shadow-lg">
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div className="flex-1 min-w-max">
                <p className="text-muted-foreground text-sm mb-1">Selected Seats</p>
                <p className="text-2xl font-bold text-primary">
                  {selectedSeats.length > 0
                    ? `${selectedSeats.length} seat${selectedSeats.length !== 1 ? "s" : ""}`
                    : "None selected"}
                </p>
              </div>
              <div className="flex-1 min-w-max">
                <p className="text-muted-foreground text-sm mb-1">Total Price</p>
                <p className="text-2xl font-bold text-accent">
                  ₹{(showTime?.basePrice || showTime?.price || 250) * selectedSeats.length}
                </p>
              </div>
              <Button
                onClick={handleBooking}
                disabled={selectedSeats.length === 0}
                className="min-w-fit px-8"
                size="lg"
              >
                Proceed to Payment
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
