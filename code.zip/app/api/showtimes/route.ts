import { connectToDatabase } from "@/lib/mongodb"

export async function GET(request: Request) {
  try {
    const url = new URL(request.url)
    const movieId = url.searchParams.get("movieId")

    const db = await connectToDatabase().then((c) => c.db)

    const query = movieId ? { movieId } : {}
    const showtimes = await db.collection("showtimes").find(query).toArray()

    return Response.json({
      success: true,
      data: showtimes.map((s) => ({ ...s, _id: s._id?.toString() })),
    })
  } catch (error) {
    console.error("GET /api/showtimes error:", error)
    return Response.json({ success: false, message: "Failed to fetch showtimes" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const db = await connectToDatabase().then((c) => c.db)

    const result = await db.collection("showtimes").insertOne({
      ...body,
      createdAt: new Date(),
    })

    // Create seats for this showtime
    const seats = []
    const rows = ["A", "B", "C", "D", "E", "F", "G", "H"]
    const seatsPerRow = 12

    for (const row of rows) {
      for (let i = 1; i <= seatsPerRow; i++) {
        seats.push({
          showTimeId: result.insertedId.toString(),
          row,
          number: i,
          status: "available",
          createdAt: new Date(),
        })
      }
    }

    await db.collection("seats").insertMany(seats)

    return Response.json({
      success: true,
      data: { _id: result.insertedId, ...body },
    })
  } catch (error) {
    console.error("POST /api/showtimes error:", error)
    return Response.json({ success: false, message: "Failed to create showtime" }, { status: 500 })
  }
}
