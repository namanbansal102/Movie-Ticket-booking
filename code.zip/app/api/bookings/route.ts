import { connectToDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

function generateBookingId(): string {
  return "BK" + Date.now() + Math.random().toString(36).substr(2, 9)
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const db = await connectToDatabase().then((c) => c.db)

    const bookingId = generateBookingId()

    // Create booking
    const bookingResult = await db.collection("bookings").insertOne({
      ...body,
      bookingId,
      createdAt: new Date(),
    })

    // Update seat statuses to booked
    const seatIds = body.seatIds.map((id: string) => new ObjectId(id))
    await db.collection("seats").updateMany({ _id: { $in: seatIds } }, { $set: { status: "booked" } })

    return Response.json({
      success: true,
      data: {
        _id: bookingResult.insertedId,
        bookingId,
        ...body,
      },
    })
  } catch (error) {
    console.error("POST /api/bookings error:", error)
    return Response.json({ success: false, message: "Failed to create booking" }, { status: 500 })
  }
}
